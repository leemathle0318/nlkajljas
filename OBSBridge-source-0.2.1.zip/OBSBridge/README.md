# OBSBridge 0.2.1：网络错误修正 + 精确映射诊断（未完成真机验收）

本版针对已知测试设备 **iPhone 8 Plus / iOS 15.0.2 / rootless** 重构；15.0–16.6 与 SE2 仍是适配目标，不是通过记录。不是稳定成品，不能宣称已在 TikTok 正式直播跑通。

## 0.2.0 手机反馈与本版边界

用户最新截图（iPhone 8 Plus / iOS 15.0.2）证实：快捷菜单运行，媒体模块有新心跳与 1 个输出节点；接收层在 `poll` 返回 `errno=1 / Operation not permitted` 后退出。收包、解码、替换、混音均为 0；媒体端共享控制面映射失败。

0.2.1 删除接收线程的 `poll` 调用，改用非阻塞 `accept/recv` 和 10 ms 有界等待。EINTR 重试，EAGAIN/EWOULDBLOCK 等待，其他错误仍明确报错；没有绕过权限，也没有证据保证这台手机的 `accept/recv` 一定允许。修正中文 UTF-8 状态格式化，并通过独立通知状态区分共享 ID、Lookup 返回空、基地址、对齐、分配大小、协议标记/版本/大小错误。

**共享映射问题尚未修复：0.2.0 的泛化错误不足以判定根因。本版新增精确诊断，而不是声称换网络读取就能完成摄像头替换。** 两路声音和真实画面均未通过，不能用于宣称已验证直播功能。

## 保留的架构

- SpringBoard 模块负责音量上→音量下菜单、TCP 监听、MPEG-TS 解复用、H.264/AAC 解码和有界共享媒体发布。接收不再依赖视频/音频 Hook 匹配。
- mediaserverd 模块不建立网络连接、不装载 FFmpeg，仅在 `BWNodeOutput emitSampleBuffer:` 的系统输出边界处理支持的颜色帧与 PCM 音频。枚举直接覆写方法的子类，按槽保存原方法；嵌套调用和样本附件避免重复替换/混音。
- IOSurface 控制面 + 3 槽共享视频 + 2 秒单声道 Float32 PCM 环，保留共同主机时钟调度。只在共享内存中使用固定布局的 lock-free 原子类型，不跨进程传 Objective-C 对象或进程内互斥锁。
- TCP 的 socket/bind/listen 错误显示操作名、errno 和错误文字；状态分别显示监听、TCP 字节、允许/拒绝连接、解码、共享发布、媒体心跳、真实回调和替换/混音计数。
- 快捷菜单直接读取本进程状态；媒体模块通过独立 Darwin notify 心跳回报，不再用一个“没有状态文件”的提示代替加载诊断。

## GitHub 构建

1. 上传 `OBSBridge-source-0.2.1.zip` 原文件，不用解压；保留一份 0.2.1 源码即可。旧版源码会被新版工作流跳过。
2. 必须将仓库根目录 `.github/workflows/build-deb.yml` 替换为“GitHub工作流-0.2.1网络诊断修正版.txt”的内容。ZIP 内的工作流不会自己替换仓库工作流。
3. 提交后在同一分支启动新的 Actions 运行，不重跑旧提交的失败记录。
4. `OBSBridge-rootless-deb` 产物仅含 deb；`OBSBridge-build-materials` 保留依赖源码、许可证及重链接材料。下载新 deb，确认版本 0.2.1 后安装。与旧版包 ID 相同，作为升级替换。
5. 安装后用越狱工具重启用户空间，保证两套进程模块均重新加载。设置入口并非本次修复重点，仍可用音量快捷菜单。

## 按三段验收，不再一次判断全部功能

### 1. 接收与解码（先不打开相机）

手机与电脑在可信局域网。解锁桌面短按音量上→0.8 秒内音量下；菜单填写 **电脑** IPv4，点“开始接收 OBS”。查看状态必须明确报告 `TCP 监听 是`，否则按提示的 socket/bind/listen/fcntl/accept 操作和 errno 排查，不继续猜 OBS 编码。

OBS：高级输出→录制→自定义 FFmpeg，输出到 URL 而非本地文件。URL 为手机复制出的 `tcp://手机Wi-Fi-IP:5000`。容器 mpegts，视频 libx264，音频 AAC 48 kHz。建议起测 360×640 / 30 FPS，无 B 帧，1 秒关键帧；视频编码选项 `preset=veryfast tune=zerolatency bf=0 g=30`。先启用手机接收，再在 OBS 开始录制（这里表示发送网络流）。

状态中的 TCP 字节及视频/音频解码计数应增加；拒绝连接增加时，检查菜单允许的电脑 IP 与状态中的实际来源。解码增加只证明接收层工作，不是摄像头替换成功。

### 2. 系统视频

打开系统相机的视频模式或目标应用的私密预览，再查看媒体状态。必须看到新心跳、兼容输出节点、视频回调及实际替换计数，且实际显示 OBS 带方向标记的画面。心跳有但回调为零、共享映射失败、发布成功但替换为零，是不同故障。

### 3. 两路声音

OBS 源含可辨认的视频声音；同时手机麦克风旁说话/拍手，先录制短样本并回听。混音计数只能说明一个支持的系统 PCM 节点被处理，最终接收端必须能同时听到两路。电脑麦克风不需要加入 OBS，以免双重录音。手机扬声器不需要播放 OBS 声音来冒充数字混音。

停止时点“停止并恢复真实摄像头”，并停掉 OBS 网络输出。

## 明确限制

- 未在本次手机运行；公开私有节点/IOSurface 属性不是 Apple 跨小版本兼容承诺。IOSurfaceLookup 或通知受限时会回报失败，没有实现沙盒绕过。
- 视频支持 BGRA、8-bit NV12；音频支持 little-endian packed Float32/Int16，最多 8 通道、8192 帧。其他格式透传真实输入。
- 不注入目标应用、不用 AVCapture 委托替换作兜底。某些 WebRTC/直播音频 SDK 不经过这个系统节点，需要单独验收，不能用系统相机录像成功替代直播验收。
- 不承诺拍照、AR、深度、HDR/10-bit、Face ID、电话音频等功能。只测试实时视频与支持的麦克风路径。
- 断流、过期、共享不可见、未匹配或不支持格式会恢复/保留真实输入；本版不是隐私隔离工具。
- SpringBoard 承担解码；起测应使用低分辨率。视频队列最多 6 帧，发布仅 3 槽，音频 2 秒；1080p、长时间和压力场景仍需测量内存/CPU。若消费者崩溃留下共享槽租约，发布可能被阻塞；会显示发布失败计数，重启用户空间会重建共享面，不能宣称已验证自动恢复。
- 无加密/口令，仅允许配置的电脑 IP，不要公网映射 5000 端口。

## 已执行检查与未完成项

见 `TEST_RESULTS.md`：包括真实 iOS arm64 对象文件生成、共享 PCM 双进程协议测试、混音/时间线测试和电脑回环 TCP 冒烟测试。**未完成完整 Theos 链接签名/arm64e 构建和真机三段验收**，不能把这些检查称为完整可用。

## 参考依据

- 系统输出边界示例：https://github.com/EthanArbuckle/vcam-ios/blob/main/Tweak.x （作者标为 POC，不直接照搬其媒体加载/内存实现）。
- 进程分离与共享面思路：https://github.com/GUSHU101/VCamLab-2.0/blob/main/ARCHITECTURE.md （其网络来源不提供本任务需要的混音；本版协议与代码自行实现）。
- ElleKit 加载流程：https://github.com/tealbathingsuit/ellekit/blob/main/injector/injector.c
- Theos rootless：https://theos.dev/docs/rootless
- 中文状态格式化：[Apple 字符串格式说明](https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/Strings/Articles/formatSpecifiers.html)。`%s` 按系统默认编码解释，不能代替显式 UTF-8 解码；本版先转换为 NSString，再用 `%@`。

本工程未复制参考 deb 的实现/二进制，未将其他作者的声明当作本设备通过记录。FFmpeg LGPL 的源码、对象与许可证分发要求见 `THIRD_PARTY.md`。
