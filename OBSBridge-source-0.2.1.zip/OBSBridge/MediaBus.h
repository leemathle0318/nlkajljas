#pragma once
#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#include "core/SharedMedia.hpp"
#import <IOSurface/IOSurfaceRef.h>
#include <memory>

// Producer methods are only used in SpringBoard. The control surface persists
// for that process's lifetime, including while receiving is stopped.
NSString *OBBusCreate(void);
void OBBusEnable(BOOL enabled);
void OBBusHeartbeat(void);
void OBBusResetAudio(void);
void OBBusWriteAudio(const float *samples, size_t count, double due);
BOOL OBBusPublishVideo(CVPixelBufferRef source, double due);
NSString *OBBusProducerStatus(void);
// Consumer mappings report lookup failures rather than silently failing.
struct OBMapping {
    IOSurfaceRef surface;
    obs::SharedMedia *data;
    OBMapping(IOSurfaceRef s, obs::SharedMedia *d) : surface(s), data(d) {}
    ~OBMapping() { CFRelease(surface); }
};
struct OBVideoLease {
    std::shared_ptr<OBMapping> mapping;
    unsigned slot;
    CVPixelBufferRef pixel;
    OBVideoLease(std::shared_ptr<OBMapping> m, unsigned s, CVPixelBufferRef p) : mapping(m), slot(s), pixel(p) {}
    ~OBVideoLease() { CVPixelBufferRelease(pixel); obs::releaseReader(mapping->data->video[slot]); }
};
std::shared_ptr<OBMapping> OBBusConsumer(void);
NSString *OBBusConsumerError(void);
// A lease must remain held until the pixel buffer has finished being consumed.
std::unique_ptr<OBVideoLease> OBBusCopyVideo(void);
void OBMediaHeartbeat(uint32_t hookCount, uint64_t videoCalls, uint64_t audioCalls,
                      uint64_t replaced, uint64_t mixed, uint32_t failure);
NSString *OBMediaStatus(void);
FOUNDATION_EXPORT double OBNow(void);
