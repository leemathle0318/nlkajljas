#pragma once
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *OBCWiFiIP(void);
FOUNDATION_EXPORT NSString *OBCPeerIP(void);
// nil = saved and read back from the shared configuration, otherwise an error.
FOUNDATION_EXPORT NSString *OBCSavePeerIP(NSString *peer);
FOUNDATION_EXPORT NSString *OBCURL(void);
// nil = command saved and notification posted, NOT a receiver startup acknowledgement.
FOUNDATION_EXPORT NSString *OBCSendCommand(BOOL enabled, NSString *peer);
FOUNDATION_EXPORT NSString *OBCStatus(void);
